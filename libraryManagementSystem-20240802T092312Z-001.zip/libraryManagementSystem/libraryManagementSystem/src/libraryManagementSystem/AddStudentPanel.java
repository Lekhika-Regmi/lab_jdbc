package libraryManagementSystem;
import javax.swing.*;

import java.awt.GridLayout;
import java.awt.event.*;

public class AddStudentPanel extends JPanel implements ActionListener {
    JTextField firstNameField, lastNameField, genderField, programField, sectionField;
    JButton addButton;

    public AddStudentPanel() {
        setLayout(new GridLayout(6, 2));

        firstNameField = new JTextField(15);
        lastNameField = new JTextField(15);
        genderField = new JTextField(15);
        programField = new JTextField(15);
        sectionField = new JTextField(15);
        addButton = new JButton("Add Student");

        add(new JLabel("First Name:"));
        add(firstNameField);
        add(new JLabel("Last Name:"));
        add(lastNameField);
        add(new JLabel("Gender:"));
        add(genderField);
        add(new JLabel("Program:"));
        add(programField);
        add(new JLabel("Section:"));
        add(sectionField);
        add(addButton);

        addButton.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            Student student = new Student(firstNameField.getText(), lastNameField.getText(), genderField.getText(), programField.getText(), sectionField.getText());
            DataBaseOperation.writeStudentData(student);
            JOptionPane.showMessageDialog(this, "Student added successfully!");
        }
    }
}
