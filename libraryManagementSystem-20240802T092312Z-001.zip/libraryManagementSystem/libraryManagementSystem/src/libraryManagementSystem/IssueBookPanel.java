package libraryManagementSystem;

import javax.swing.*;

import java.awt.GridLayout;
import java.awt.event.*;

public class IssueBookPanel extends JPanel implements ActionListener {
    JTextField studentIdField, bookIdField, issueDateField, dueDateField;
    JButton issueButton;

    public IssueBookPanel() {
        setLayout(new GridLayout(5, 2));

        studentIdField = new JTextField(15);
        bookIdField = new JTextField(15);
        issueDateField = new JTextField(15);
        dueDateField = new JTextField(15);
        issueButton = new JButton("Issue Book");

        add(new JLabel("Student ID:"));
        add(studentIdField);
        add(new JLabel("Book ID:"));
        add(bookIdField);
        add(new JLabel("Issue Date:"));
        add(issueDateField);
        add(new JLabel("Due Date:"));
        add(dueDateField);
        add(issueButton);

        issueButton.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == issueButton) {
            BookIssue bookIssue = new BookIssue(Integer.parseInt(studentIdField.getText()), Integer.parseInt(bookIdField.getText()), issueDateField.getText(), dueDateField.getText());
            DataBaseOperation.writeBookIssued(bookIssue);
            JOptionPane.showMessageDialog(this, "Book issued successfully!");
        }
    }
}
