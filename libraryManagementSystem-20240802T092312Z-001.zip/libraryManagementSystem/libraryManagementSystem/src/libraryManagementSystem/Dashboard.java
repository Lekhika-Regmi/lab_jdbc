package libraryManagementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Dashboard extends JFrame {
    JTabbedPane tabbedPane;

    public Dashboard() {
        tabbedPane = new JTabbedPane();
        tabbedPane.add("Add Student", new AddStudentPanel());
        tabbedPane.add("Add Book", new AddBookPanel());
        tabbedPane.add("Issue Book", new IssueBookPanel());
        tabbedPane.add("Display Record", new DisplayRecordPanel());

        add(tabbedPane);
        setTitle("Dashboard");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Dashboard();
    }
}
