package libraryManagementSystem;

public class Book {
    private String author, title, publication, subject;

    public Book(String author, String title, String publication, String subject) {
        this.author = author;
        this.title = title;
        this.publication = publication;
        this.subject = subject;
    }

    // Getters
    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public String getPublication() {
        return publication;
    }

    public String getSubject() {
        return subject;
    }
}
