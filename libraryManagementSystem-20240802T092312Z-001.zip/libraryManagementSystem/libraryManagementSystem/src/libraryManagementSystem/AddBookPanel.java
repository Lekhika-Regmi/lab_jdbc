package libraryManagementSystem;

import javax.swing.*;

import java.awt.GridLayout;
import java.awt.event.*;

public class AddBookPanel extends JPanel implements ActionListener {
    JTextField authorField, titleField, publicationField, subjectField;
    JButton addButton;

    public AddBookPanel() {
        setLayout(new GridLayout(5, 2));

        authorField = new JTextField(15);
        titleField = new JTextField(15);
        publicationField = new JTextField(15);
        subjectField = new JTextField(15);
        addButton = new JButton("Add Book");

        add(new JLabel("Author Name:"));
        add(authorField);
        add(new JLabel("Title:"));
        add(titleField);
        add(new JLabel("Publication:"));
        add(publicationField);
        add(new JLabel("Subject:"));
        add(subjectField);
        add(addButton);

        addButton.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            Book book = new Book(authorField.getText(), titleField.getText(), publicationField.getText(), subjectField.getText());
            DataBaseOperation.writeBookData(book);
            JOptionPane.showMessageDialog(this, "Book added successfully!");
        }
    }
}
