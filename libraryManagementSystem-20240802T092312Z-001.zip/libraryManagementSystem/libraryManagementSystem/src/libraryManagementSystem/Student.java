package libraryManagementSystem;

public class Student {
    private String firstName, lastName, gender, program, section;

    public Student(String firstName, String lastName, String gender, String program, String section) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.program = program;
        this.section = section;
    }

    // Getters
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getGender() {
        return gender;
    }

    public String getProgram() {
        return program;
    }

    public String getSection() {
        return section;
    }
}
