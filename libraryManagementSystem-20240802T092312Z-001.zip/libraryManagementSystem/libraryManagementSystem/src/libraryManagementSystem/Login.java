package libraryManagementSystem;

import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.HashMap;

public class Login extends JFrame implements ActionListener {
    JTextField userField;
    JPasswordField passField;
    JButton loginButton, registerButton;
    HashMap<String, String> credentials = new HashMap<>();

    public Login() {
        // GUI setup
        userField = new JTextField(15);
        passField = new JPasswordField(15);
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");

        // Load credentials
        loadCredentials();

        JPanel panel = new JPanel();
        panel.add(new JLabel("Username:"));
        panel.add(userField);
        panel.add(new JLabel("Password:"));
        panel.add(passField);
        panel.add(loginButton);
        panel.add(registerButton);

        add(panel);
        loginButton.addActionListener(this);
        registerButton.addActionListener(this);
        setTitle("Login");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String username = userField.getText();
        String password = new String(passField.getPassword());

        if (e.getSource() == registerButton) {
            credentials.put(username, password);
            saveCredentials();
            JOptionPane.showMessageDialog(this, "Registered Successfully!");
        } else if (e.getSource() == loginButton) {
            if (credentials.containsKey(username) && credentials.get(username).equals(password)) {
                new Dashboard();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Credentials!");
            }
        }
    }

    private void loadCredentials() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("credentials.ser"))) {
            credentials = (HashMap<String, String>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {   
        	
        }
    }

    private void saveCredentials() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("credentials.ser"))) {
            oos.writeObject(credentials);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}

