package libraryManagementSystem;

public class BookIssue {
    private int studentId, bookId;
    private String issueDate, dueDate;

    public BookIssue(int studentId, int bookId, String issueDate, String dueDate) {
        this.studentId = studentId;
        this.bookId = bookId;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
    }

    // Getters
    public int getStudentId() {
        return studentId;
    }

    public int getBookId() {
        return bookId;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public String getDueDate() {
        return dueDate;
    }
}
