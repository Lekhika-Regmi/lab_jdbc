package libraryManagementSystem;
import java.sql.*;
import java.util.ArrayList;

public class DataBaseOperation {

    // Method to write student data
    public static void writeStudentData(Student student) {
        String query = "INSERT INTO student (firstName, lastName, gender, program, section) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, student.getFirstName());
            pstmt.setString(2, student.getLastName());
            pstmt.setString(3, student.getGender());
            pstmt.setString(4, student.getProgram());
            pstmt.setString(5, student.getSection());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to read all student data
    public static ArrayList<Student> readStudents() {
        ArrayList<Student> students = new ArrayList<>();
        String query = "SELECT * FROM student";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Student student = new Student(
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("gender"),
                        rs.getString("program"),
                        rs.getString("section")
                );
                students.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    // Method to write book data
    public static void writeBookData(Book book) {
        String query = "INSERT INTO book (author, title, publication, subject) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, book.getAuthor());
            pstmt.setString(2, book.getTitle());
            pstmt.setString(3, book.getPublication());
            pstmt.setString(4, book.getSubject());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to read all book data
    public static ArrayList<Book> readBooks() {
        ArrayList<Book> books = new ArrayList<>();
        String query = "SELECT * FROM book";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Book book = new Book(
                        rs.getString("author"),
                        rs.getString("title"),
                        rs.getString("publication"),
                        rs.getString("subject")
                );
                books.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    // Method to write book issue data
    public static void writeBookIssued(BookIssue bookIssue) {
        String query = "INSERT INTO book_issue (studentId, bookId, issueDate, dueDate) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, bookIssue.getStudentId());
            pstmt.setInt(2, bookIssue.getBookId());
            pstmt.setString(3, bookIssue.getIssueDate());
            pstmt.setString(4, bookIssue.getDueDate());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to read all book issue data
    public static ArrayList<BookIssue> readBookIssues() {
        ArrayList<BookIssue> issues = new ArrayList<>();
        String query = "SELECT * FROM book_issue";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                BookIssue issue = new BookIssue(
                        rs.getInt("studentId"),
                        rs.getInt("bookId"),
                        rs.getString("issueDate"),
                        rs.getString("dueDate")
                );
                issues.add(issue);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return issues;
    }

    // Method to get student by ID
    public static Student getStudentById(int id) {
        String query = "SELECT * FROM student WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Student(
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("gender"),
                        rs.getString("program"),
                        rs.getString("section")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to get book by ID
    public static Book getBookById(int id) {
        String query = "SELECT * FROM book WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Book(
                        rs.getString("author"),
                        rs.getString("title"),
                        rs.getString("publication"),
                        rs.getString("subject")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
