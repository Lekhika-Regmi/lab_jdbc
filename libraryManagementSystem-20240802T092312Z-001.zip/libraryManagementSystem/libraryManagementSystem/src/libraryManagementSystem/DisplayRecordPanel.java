package libraryManagementSystem;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class DisplayRecordPanel extends JPanel {
    JTextArea recordArea;

    public DisplayRecordPanel() {
        recordArea = new JTextArea(20, 30);
        recordArea.setEditable(false);
        setLayout(new BorderLayout());
        add(new JScrollPane(recordArea), BorderLayout.CENTER);
        SwingUtilities.invokeLater(this::displayRecords);
    }

    private void displayRecords() {
        StringBuilder records = new StringBuilder();
        ArrayList<BookIssue> issues = DataBaseOperation.readBookIssues();
        System.out.println("Number of book issues retrieved: " + issues.size());

        for (BookIssue issue : issues) {
            Student student = DataBaseOperation.getStudentById(issue.getStudentId());
            Book book = DataBaseOperation.getBookById(issue.getBookId());
            if (student != null && book != null) {
                records.append(String.format(
                        "Student: %s %s, Program: %s, Section: %s\nBook: %s, Author: %s\nIssue Date: %s, Due Date: %s\n\n",
                        student.getFirstName(), student.getLastName(), student.getProgram(), student.getSection(),
                        book.getTitle(), book.getAuthor(), issue.getIssueDate(), issue.getDueDate()
                ));
            } else {
                System.out.println("Missing data for issue: " + issue);
            }
        }
        recordArea.setText(records.toString());
    }

}
