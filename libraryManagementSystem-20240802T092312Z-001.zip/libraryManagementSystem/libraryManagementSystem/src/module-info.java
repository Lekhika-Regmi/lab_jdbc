/**
 * 
 */
/**
 * @author Lenovo
 *
 */
module libraryManagementSystem {
	requires java.desktop;
	requires java.sql;
}